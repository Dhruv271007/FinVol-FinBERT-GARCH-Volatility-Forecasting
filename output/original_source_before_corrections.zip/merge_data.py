import pandas as pd
import numpy as np
from yfinancedownload import log_returns, realized_vol

tickers = ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", 
           "META", "BRK-B", "LLY", "AVGO", "TSLA"]

def build_merged(ticker):
    # --- Sentiment ---
    sent = pd.read_csv(f"{ticker}_sentiment.csv")
    sent['date'] = pd.to_datetime(sent['date'],utc =True).dt.tz_localize(None)
    sent['date'] = sent['date'].dt.floor('D')
    # Aggregate to daily mean sentiment on the RAW calendar
    # No shifting here — we shift after merging onto trading calendar
    daily_sent = sent.groupby('date')['sentiment'].mean()

    # --- Price series (already on trading calendar) ---
    vol = realized_vol[ticker].rename("realized_vol")
    ret = log_returns[ticker].rename("log_return")

    # --- Merge onto trading calendar ---
    # Left join: trading days are the spine
    # Sentiment dates that fall on non-trading days get dropped automatically
    merged = pd.concat([vol, ret], axis=1)
    merged.index = pd.to_datetime(merged.index).tz_localize(None) ##remove timezone information as intraday timings do not matter 
    merged = merged.join(daily_sent.rename("sentiment"), how="left")

    # --- Apply lag HERE, on the trading calendar ---
    # Now shift(1) means "previous trading day's sentiment"
    # This is the correct look-ahead-safe exogenous variable
    merged["sentiment_lag1"] = merged["sentiment"].shift(1)

    # --- Handle missing sentiment ---
    # Modeling assumption: no news on a trading day = neutral (0)
    # Alternative: forward-fill last known sentiment
    # We choose 0 for now — document this choice
    merged["sentiment_lag1"] = merged["sentiment_lag1"].fillna(0)

    # --- Drop rows where price data is NaN ---
    # First 20 rows will have NaN realized_vol due to rolling(21) window
    # Do NOT fill these — they are genuinely unobservable
    merged = merged.dropna(subset=["realized_vol", "log_return"])
    return merged

# Build and save all tickers
all_merged = {}
for ticker in tickers:
    all_merged[ticker] = build_merged(ticker)
    all_merged[ticker].to_csv(f"{ticker}_merged_lagged.csv")
