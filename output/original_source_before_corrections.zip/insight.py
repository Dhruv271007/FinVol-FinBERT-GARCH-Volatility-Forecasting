import pandas as pd
import numpy as np 
import matplotlib as plt

tickers = ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "BRK-B", "LLY", "AVGO", "TSLA"]

for ticker in tickers:
    df=pd.read_csv("f{ticker}_daily_sentiment.csv")
    df.plot(kind='scatter', x='column_A', y='column_B', title='Column A vs Column B')
    plt.show()
