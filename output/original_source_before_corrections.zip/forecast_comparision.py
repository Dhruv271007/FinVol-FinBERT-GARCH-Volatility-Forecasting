import pandas as pd
import numpy as np
from scipy.optimize import minimize
from merge_data import tickers

# ---------- GARCH(1,1) ----------

def garch_variance(params, returns):
    mu, omega, alpha, beta = params
    T = len(returns)
    eps = returns - mu
    sigma2 = np.empty(T)
    sigma2[0] = np.var(returns)
    for t in range(1, T):
        sigma2[t] = omega + alpha*eps[t-1]**2 + beta*sigma2[t-1]
        if not np.isfinite(sigma2[t]) or sigma2[t] <= 0:
            return None
    return sigma2

def garch_nll(params, returns):
    sigma2 = garch_variance(params, returns)
    if sigma2 is None:
        return 1e10
    mu = params[0]
    eps = returns - mu
    nll = 0.5*np.sum(np.log(2*np.pi) + np.log(sigma2) + eps**2/sigma2)
    return nll if np.isfinite(nll) else 1e10

def fit_garch(returns):
    x0 = [0.1, 0.05, 0.05, 0.9]
    bounds = [(-1,1),(1e-6,None),(0,1),(0,1)]
    return minimize(garch_nll, x0=x0, args=(returns,), bounds=bounds, method="L-BFGS-B")

# ---------- GARCH-X ----------

def garch_x_variance(params, returns, sentiment):
    mu, omega, alpha, beta, gamma = params
    T = len(returns)
    eps = returns - mu
    sigma2 = np.empty(T)
    sigma2[0] = np.var(returns)
    for t in range(1, T):
        sigma2[t] = omega + alpha*eps[t-1]**2 + beta*sigma2[t-1] + gamma*sentiment[t]
        if not np.isfinite(sigma2[t]) or sigma2[t] <= 0:
            return None
    return sigma2

def garch_x_nll(params, returns, sentiment):
    sigma2 = garch_x_variance(params, returns, sentiment)
    if sigma2 is None:
        return 1e10
    mu = params[0]
    eps = returns - mu
    nll = 0.5*np.sum(np.log(2*np.pi) + np.log(sigma2) + eps**2/sigma2)
    return nll if np.isfinite(nll) else 1e10

def fit_garch_x(returns, sentiment):
    x0 = [0.1, 0.05, 0.05, 0.9, 0.1]
    bounds = [(-1,1),(1e-6,None),(0,1),(0,1),(-5,5)]
    return minimize(garch_x_nll, x0=x0, args=(returns, sentiment), bounds=bounds, method="L-BFGS-B")

# ---------- Build the forecasts you'll feed into Diebold-Mariano ----------

def run_ticker(ticker, test_frac=0.2):
    df = pd.read_csv(f"{ticker}_merged_lagged.csv", index_col="Date", parse_dates=True)
    returns = (df["log_return"] * 100).values
    sentiment = df["sentiment_lag1"].values

    split = int(len(returns) * (1 - test_frac))
    train_r, train_s = returns[:split], sentiment[:split]

    res_g  = fit_garch(train_r)
    res_gx = fit_garch_x(train_r, train_s)

    if not (res_g.success and res_gx.success):
        print(f"{ticker}: convergence failed, skipping")
        return None

    sigma2_g  = garch_variance(res_g.x, returns)
    sigma2_gx = garch_x_variance(res_gx.x, returns, sentiment)

    if sigma2_g is None or sigma2_gx is None:
        print(f"{ticker}: invalid variance path, skipping")
        return None

    mu_g = res_g.x[0]
    realized = (returns[split:] - mu_g) ** 2

    return {
        "ticker": ticker,
        "realized": realized,
        "forecast_garch": sigma2_g[split:],
        "forecast_garch_x": sigma2_gx[split:],
        "params_garch": res_g.x,
        "params_garch_x": res_gx.x,
    }

all_results = {}
for ticker in tickers:
    out = run_ticker(ticker)
    if out is not None:
        all_results[ticker] = out
        print(f"{ticker}: done, {len(out['realized'])} test-day forecasts ready")


from scipy.stats import norm

def diebold_mariano(loss_a, loss_b, h=1):
    """
    Tests whether loss_a (e.g. GARCH) is significantly different from loss_b (GARCH-X).
    Positive DM stat -> loss_a bigger -> model B (GARCH-X) forecasts better.
    """
    d = loss_a - loss_b
    T = len(d)
    d_mean = np.mean(d)

    # --- Newey-West long-run variance of d_t ---
    gamma0 = np.var(d, ddof=0)
    max_lag = h - 1
    nw_var = gamma0
    for k in range(1, max_lag + 1):
        cov_k = np.cov(d[:-k], d[k:])[0, 1]
        weight = 1 - k / (max_lag + 1)
        nw_var += 2 * weight * cov_k

    se = np.sqrt(nw_var / T)
    dm_stat = d_mean / se
    p_value = 2 * (1 - norm.cdf(abs(dm_stat)))
    return dm_stat, p_value, d_mean


# --- Run it for every ticker you already fitted ---
for ticker, res in all_results.items():
    e_garch   = (res["realized"] - res["forecast_garch"])   ** 2
    e_garch_x = (res["realized"] - res["forecast_garch_x"]) ** 2

    dm_stat, p_val, d_mean = diebold_mariano(e_garch, e_garch_x)

    better = "GARCH-X" if d_mean > 0 else "GARCH(1,1)"
    sig = "SIGNIFICANT" if p_val < 0.05 else "not significant"

    print(f"{ticker:6s}  mean(e_garch)={np.mean(e_garch):.4f}  "
          f"mean(e_garch_x)={np.mean(e_garch_x):.4f}  "
          f"DM={dm_stat:6.2f}  p={p_val:.4f}  -> {better} better ({sig})")

def qlike_loss(realized, forecast):
    return realized / forecast + np.log(forecast)

print("\n=== QLIKE LOSS COMPARISON ===")
for ticker, res in all_results.items():
    q_garch   = qlike_loss(res["realized"], res["forecast_garch"])
    q_garch_x = qlike_loss(res["realized"], res["forecast_garch_x"])

    dm_stat, p_val, d_mean = diebold_mariano(q_garch, q_garch_x)

    better = "GARCH-X" if d_mean > 0 else "GARCH(1,1)"
    sig = "SIGNIFICANT" if p_val < 0.05 else "not significant"

    print(f"{ticker:6s}  QLIKE_garch={np.mean(q_garch):.4f}  "
          f"QLIKE_garch_x={np.mean(q_garch_x):.4f}  "
          f"DM={dm_stat:6.2f}  p={p_val:.4f}  -> {better} better ({sig})")