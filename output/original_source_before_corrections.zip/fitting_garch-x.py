import pandas as pd 
import numpy as np 
from arch import arch_model
from scipy.optimize import minimize 

def garch_x_negativee_log_likelihood(params,returns,sentiment):
    mu,omega,alpha,beta,gamma = params 
    T= len(returns)
    eps = returns - mu 
    sigma2 = np.zeros(T)  ## squared of sigma 
    sigma2[0] = np.var(returns)
    for t in range (1,T):
        sigma2[t] = omega + alpha*(eps[t-1]**2)+beta*(sigma2[t-1])+gamma*(sentiment[t])
        # Reject invalid variance
        if not np.isfinite(sigma2[t]) or sigma2[t] <= 0:
            return 1e10

    log_likelihood = (-0.5)*(np.sum(np.log(2*np.pi) + np.log(sigma2) + (eps**2)/sigma2))
    return -log_likelihood

def conditional_variance(params, returns, sentiment):

    mu, omega, alpha, beta, gamma = params

    T = len(returns)

    eps = returns - mu
    sigma2 = np.zeros(T)

    sigma2[0] = np.var(returns)

    for t in range(1, T):

        sigma2[t] = (
            omega
            + alpha * eps[t-1]**2
            + beta * sigma2[t-1]
            + gamma * sentiment[t]
        )

    return sigma2

# ============================================================
# Individual negative log-likelihood contributions
# ============================================================

def nll_contributions(params, returns, sentiment):

    mu, omega, alpha, beta, gamma = params

    T = len(returns)

    eps = returns - mu
    sigma2 = np.zeros(T)

    sigma2[0] = np.var(returns)

    for t in range(1, T):

        sigma2[t] = (
            omega
            + alpha * eps[t-1]**2
            + beta * sigma2[t-1]
            + gamma * sentiment[t]
        )

        # Invalid variance
        if not np.isfinite(sigma2[t]) or sigma2[t] <= 0:
            return np.full(T, 1e10)

    contributions = 0.5 * (
        np.log(2 * np.pi)
        + np.log(sigma2)
        + (eps**2) / sigma2
    )

    return contributions


# ============================================================
# Standard + robust SE + correlation matrix
# ============================================================

def compute_inference(params, returns, sentiment):

    T = len(returns)

    # --------------------------------------------------------
    # Hessian of TOTAL negative log likelihood
    # --------------------------------------------------------

    objective = lambda p: np.sum(
        nll_contributions(p, returns, sentiment)
    )

    H = nd.Hessian(objective)(params)

    # Make numerically symmetric
    H = 0.5 * (H + H.T)

    # --------------------------------------------------------
    # Ordinary Hessian covariance
    # --------------------------------------------------------

    try:
        cov_hessian = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        cov_hessian = np.linalg.pinv(H)

    se_hessian = np.sqrt(
        np.maximum(np.diag(cov_hessian), 0)
    )

    # --------------------------------------------------------
    # Score of each observation
    # --------------------------------------------------------

    jacobian = nd.Jacobian(
        lambda p: nll_contributions(
            p,
            returns,
            sentiment
        )
    )(params)

    # Shape should be:
    # T observations × 5 parameters
    scores = jacobian

    # --------------------------------------------------------
    # Robust sandwich covariance
    # --------------------------------------------------------

    A = H / T

    B = (scores.T @ scores) / T

    try:
        A_inv = np.linalg.inv(A)
    except np.linalg.LinAlgError:
        A_inv = np.linalg.pinv(A)

    cov_robust = (
        A_inv @ B @ A_inv
    ) / T

    cov_robust = 0.5 * (
        cov_robust + cov_robust.T
    )

    se_robust = np.sqrt(
        np.maximum(np.diag(cov_robust), 0)
    )

    # --------------------------------------------------------
    # Robust z-statistics and p-values
    # --------------------------------------------------------

    z_robust = params / se_robust

    from scipy.stats import norm

    p_robust = 2 * norm.sf(
        np.abs(z_robust)
    )

    # --------------------------------------------------------
    # 95% confidence intervals
    # --------------------------------------------------------

    ci_lower = params - 1.96 * se_robust
    ci_upper = params + 1.96 * se_robust

    # --------------------------------------------------------
    # Parameter correlation matrix
    # --------------------------------------------------------

    D = np.sqrt(
        np.diag(cov_robust)
    )

    correlation_matrix = (
        cov_robust /
        np.outer(D, D)
    )

    # --------------------------------------------------------
    # Final variance diagnostics
    # --------------------------------------------------------

    sigma2 = conditional_variance(
        params,
        returns,
        sentiment
    )

    floor_hits = np.sum(sigma2 <= 1e-8)

    diagnostics = {
        "min_sigma2": np.min(sigma2),
        "max_sigma2": np.max(sigma2),
        "floor_hits": floor_hits,
        "hessian_eigenvalues": np.linalg.eigvalsh(H)
    }

    return {
        "se_hessian": se_hessian,
        "se_robust": se_robust,
        "z_robust": z_robust,
        "p_robust": p_robust,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "correlation": correlation_matrix,
        "diagnostics": diagnostics
    }
import numdifftools as nd
import numpy as np




from merge_data import tickers 
for ticker in tickers:

    print("\n" + "=" * 80)
    print(f" {ticker}")
    print("=" * 80)

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    df = pd.read_csv(
        f"{ticker}_merged_lagged.csv",
        index_col="Date",
        parse_dates=True
    )

    returns = (
        df["log_return"] * 100
    ).values

    sentiment = (
        df["sentiment_lag1"]
    ).values

    # --------------------------------------------------------
    # Initial parameters
    # --------------------------------------------------------

    initial_params = [
        0.1,    # mu
        0.05,   # omega
        0.05,   # alpha
        0.9,    # beta
        0.1     # gamma
    ]

    # --------------------------------------------------------
    # Parameter bounds
    # --------------------------------------------------------

    bounds = [
        (-1, 1),       # mu
        (1e-6, None),  # omega
        (0, 1),        # alpha
        (0, 1),        # beta
        (-5, 5)        # gamma
    ]

    # --------------------------------------------------------
    # Estimate GARCH-X
    # --------------------------------------------------------

    result = minimize(
        garch_x_negativee_log_likelihood,
        x0=initial_params,
        args=(returns, sentiment),
        bounds=bounds,
        method="L-BFGS-B"
    )

    # --------------------------------------------------------
    # Parameters
    # --------------------------------------------------------

    params = result.x

    mu, omega, alpha, beta, gamma = params

    print("\nPARAMETER ESTIMATES")
    print("-" * 80)

    names = [
        "mu",
        "omega",
        "alpha",
        "beta",
        "gamma"
    ]

    for name, value in zip(names, params):
        print(
            f"{name:6s} = {value: .6f}"
        )

    print(
        f"\nalpha + beta = "
        f"{alpha + beta:.6f}"
    )

    print(
        f"Converged = {result.success}"
    )

    print(
        f"Objective = {result.fun:.6f}"
    )

    # --------------------------------------------------------
    # Statistical inference
    # --------------------------------------------------------

    inference = compute_inference(
        params,
        returns,
        sentiment
    )

    print("\nSTATISTICAL INFERENCE")
    print("-" * 80)

    for i, name in enumerate(names):

        print(
            f"{name:6s} "
            f"Estimate={params[i]: .6f}   "
            f"SE={inference['se_robust'][i]: .6f}   "
            f"z={inference['z_robust'][i]: .3f}   "
            f"p={inference['p_robust'][i]: .4f}"
        )

    # --------------------------------------------------------
    # Confidence intervals
    # --------------------------------------------------------

    print("\n95% CONFIDENCE INTERVALS")
    print("-" * 80)

    for i, name in enumerate(names):

        print(
            f"{name:6s}: "
            f"["
            f"{inference['ci_lower'][i]:.6f}, "
            f"{inference['ci_upper'][i]:.6f}"
            f"]"
        )

    # --------------------------------------------------------
    # Parameter correlation matrix
    # --------------------------------------------------------

    print("\nROBUST PARAMETER CORRELATION MATRIX")
    print("-" * 80)

    correlation_df = pd.DataFrame(
        inference["correlation"],
        index=names,
        columns=names
    )

    print(
        correlation_df.round(3)
    )

    # --------------------------------------------------------
    # Diagnostics
    # --------------------------------------------------------

    print("\nVARIANCE / HESSIAN DIAGNOSTICS")
    print("-" * 80)

    diagnostics = inference["diagnostics"]

    print(
        f"Minimum sigma² = "
        f"{diagnostics['min_sigma2']:.10f}"
    )

    print(
        f"Maximum sigma² = "
        f"{diagnostics['max_sigma2']:.10f}"
    )

    print(
        f"Variance floor hits = "
        f"{diagnostics['floor_hits']}"
    )

    print(
        "Hessian eigenvalues ="
    )

    print(
        diagnostics["hessian_eigenvalues"]
    )
    
