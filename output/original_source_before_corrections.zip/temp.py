import pandas as pd

tickers = ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "BRK-B", "LLY", "AVGO", "TSLA"]

for ticker in tickers:
    df = pd.read_csv(f"{ticker}_sentiment.csv")
    print(f"{ticker}: mean={df['sentiment'].mean():.4f}, min={df['sentiment'].min():.4f}, max={df['sentiment'].max():.4f}")