import pandas as pd 
import numpy as np 
from arch import arch_model

from merge_data import tickers

for ticker in tickers:
    df = pd.read_csv(f"{ticker}_merged_lagged.csv",index_col="Date",parse_dates=True)
    pct_returns = df["log_return"] * 100
    #rescaling returns to percentage for stability in MLE 
    model = arch_model(pct_returns, mean="Constant", vol="Garch", p=1, q=1, dist="normal")
    result = model.fit()
    print(result.summary())
    print(pct_returns.var())

